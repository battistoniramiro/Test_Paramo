﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Core.Constants;
using Test.Core.Entities;
using Test.Core.Repositories.Contracts;

namespace Test.Infrastructure.Data.Repositories
{
    public class UserTypeRepository : IUserTypeRepository
    {
        private readonly IConfiguration _config;
        private readonly string _connString;


        public UserTypeRepository(IConfiguration configuration)
        {
            _config = configuration;
            _connString = _config.GetConnectionString("Default");
        }


        public async Task<UserType> GetById(int id)
        {
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    var parameters = new
                    {
                        Id = id
                    };

                    var query = "ms_UserType_GetById";

                    using (var multi = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure))
                    {
                        UserType user = await multi.ReadFirstOrDefaultAsync<UserType>();

                        return user;
                    }
                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserNotFound);
            }
        }

    }
}
