﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Test.Core.Constants;
using Test.Core.Entities;
using Test.Core.Enums;
using Test.Core.Exceptions;
using Test.Core.Repositories.Contracts;

namespace Tesst.Infrastucture.Data.Repositories
{
    public class UserRepository : IUserRepository
    {

        private readonly IConfiguration _config;
        private readonly string _connString;


        public UserRepository(IConfiguration configuration)
        {
            _config = configuration;
            _connString = _config.GetConnectionString("Default");
        }

        public async Task<int> Add(User entity)
        {
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    var parameters = new
                    {
                        Name = entity.Name,
                        Email = entity.Email,
                        Address = entity.Address,
                        Phone = entity.Phone,
                        UserTypeId = entity.UserTypeId,
                        Money = entity.Money
                    };


                    var query = "ms_User_Add";


                    var result = await connection.QueryAsync<int>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);

                    entity.Id = result.FirstOrDefault();
                }

                return entity.Id;
            }
            catch
            {
                throw new Exception(ErrorKeys.UserWasNotCreated);
            }

        }

        public async Task<User> GetById(int id)
        {

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    var parameters = new
                    {
                        Id = id
                    };


                    var query = "ms_User_GetById";

                    using (var multi = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure))
                    {
                        User user = await multi.ReadFirstOrDefaultAsync<User>();

                        return user;
                    }

                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserNotFound);
            }
        }

        public async Task<User> GetByEmail(string email)
        {

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    var parameters = new
                    {
                        Email = email
                    };


                    var query = "ms_User_GetByEmail";

                    using (var multi = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure))
                    {
                        User user = await multi.ReadFirstOrDefaultAsync<User>();

                        return user;
                    }

                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserNotFound);
            }
        }


        public async Task<List<User>> GetAll()
        {
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                 
                    var query = "ms_User_GetAll";

                    var result = (await connection.QueryAsync<User>(query, commandType: System.Data.CommandType.StoredProcedure)).ToList();

                    return result;
                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserNotFound);
            }
        }


        public async Task Update(User dto)
        {
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                
                    var query = "ms_User_Update";

                    var parameters = new
                    {
                        Id = dto.Id,
                        Name = dto.Name,
                        Email = dto.Email,
                        Address = dto.Address,
                        Phone = dto.Phone,
                        UserTypeId = dto.UserTypeId,
                        Money = dto.Money
                    };

                    await connection.QueryAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserWasNotModified);
            }
        }

        public async Task Delete(int id)
        {

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    var parameters = new
                    {
                        Id = id
                    };

                    var query = "ms_User_Delete";

                    await connection.QueryAsync<int>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                }
            }
            catch
            {
                throw new Exception(ErrorKeys.UserWasNotDeleted);
            }
        }
    }
}
