﻿using Tesst.Infrastucture.Data.Repositories;
using Test.Core.Contracts.UnitOfWork;
using Test.Core.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Test.Infrastructure.Data.Repositories;

namespace Test.Infrastructure.Data.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {

        private IUserRepository _users;
        private IUserTypeRepository _usersType;
        private IConfiguration _config;


        public UnitOfWork(IConfiguration configuration)
        { 
            _config = configuration;    
        }

        public IUserRepository Users => _users ??= new UserRepository(_config);
        public IUserTypeRepository UsersType => _usersType ??= new UserTypeRepository(_config);


    }
}
