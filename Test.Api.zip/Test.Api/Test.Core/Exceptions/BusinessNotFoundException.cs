﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Core.Exceptions
{
    public class BusinessNotFoundException : BusinessException
    {
        public BusinessNotFoundException() : base("Could not find the requested resource") { }

        public BusinessNotFoundException(string message) : base(message) { }
    }
}
