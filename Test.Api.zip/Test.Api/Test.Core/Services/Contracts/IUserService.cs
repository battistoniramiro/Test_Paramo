﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Test.Core.Dtos;
using Test.Core.Entities;

namespace Test.Core.Services.Contracts
{
    public interface IUserService
    {
        Task<int> Add(UserDto dto);
        Task<User> GetById(int id);
        Task<List<User>> GetAll();
        Task Update(UserDto dto);
        Task Delete(int id);
    }
}
