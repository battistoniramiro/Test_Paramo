﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Test.Core.Constants;
using Test.Core.Contracts.UnitOfWork;
using Test.Core.Dtos;
using Test.Core.Entities;
using Test.Core.Enums;
using Test.Core.Exceptions;
using Test.Core.Helpers;
using Test.Core.Services.Contracts;

namespace Test.Core.Services.Implementation
{
    public class UserService : IUserService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
      
        public UserService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }


        public async Task<int> Add(UserDto dto)
        {
            await ValidateOnCreateAndEdit(dto,false);
            CalculateMoney(dto);

            var entity = _mapper.Map<User>(dto);
            var result = await _unitOfWork.Users.Add(entity);

            if (result <= 0)
                throw new BusinessException(ErrorKeys.UserWasNotCreated);

            return result;

        }

        public async Task<User> GetById(int id)
        {
            var user = await _unitOfWork.Users.GetById(id);

            if (user == null)
                throw new BusinessException(ErrorKeys.UserNotFound);

            return user;
        }

        public async Task<List<User>> GetAll()
        {
            var users = await _unitOfWork.Users.GetAll();

            if (!users.Any())
                throw new BusinessException(ErrorKeys.UsersNoContent);

            return users;
        }

        public async Task Update(UserDto dto)
        {
            await ValidateOnCreateAndEdit(dto, true);
            var entity = _mapper.Map<User>(dto);
            await _unitOfWork.Users.Update(entity);
        }

        public async Task Delete(int id)
        {
            await _unitOfWork.Users.Delete(id);
        }


        private async Task ValidateOnCreateAndEdit(UserDto dto,bool isEdit)
        {
            if (isEdit && dto.Id <= 0)
                throw new BusinessException(ErrorKeys.UserIdInvalidForModifier);

            var userExist = await _unitOfWork.Users.GetByEmail(dto.Email);

            if (userExist != null)
                throw new BusinessException(ErrorKeys.UserAlReadyExists);

            if (string.IsNullOrWhiteSpace(dto.Name))
                throw new BusinessException(ErrorKeys.UserNameIsRequired);
            
            if (string.IsNullOrWhiteSpace(dto.Email))
                throw new BusinessException(ErrorKeys.UserEmailIsRequired);

            var isValidEmail = EmailHelper.IsValid(dto.Email);

            if (!isValidEmail)
                throw new BusinessException(ErrorKeys.UserEmailIsNotValid);

            var userTypeExist = await _unitOfWork.UsersType.GetById(dto.UserTypeId);

            if (userTypeExist == null)
                throw new BusinessException(ErrorKeys.UserTypeIsNotValid);
        }




        private void CalculateMoney(UserDto dto)
        {
            switch (dto.UserTypeId)
            {
                case (int)Enums.UserType.Normal:
                    if (dto.Money > 100)
                    {
                        var percentage = Convert.ToDecimal(0.12);
                        var gif = dto.Money * percentage;
                        dto.Money = dto.Money + gif;
                    }
                    if (dto.Money < 100)
                    {
                        if (dto.Money > 10)
                        {
                            var percentage = Convert.ToDecimal(0.8);
                            var gif = dto.Money * percentage;
                            dto.Money = dto.Money + gif;
                        }
                    }
                    break;
                case (int)Enums.UserType.SuperUser:
                    if (dto.Money > 100)
                    {
                        var percentage = Convert.ToDecimal(0.20);
                        var gif = dto.Money * percentage;
                        dto.Money = dto.Money + gif;
                    }
                    break;
                case (int)Enums.UserType.Premium:
                    if (dto.Money > 100)
                    {
                        var gif = dto.Money * 2;
                        dto.Money = dto.Money + gif;
                    }
                    break;
                default:
                    break;
            }

        }


    }
}
