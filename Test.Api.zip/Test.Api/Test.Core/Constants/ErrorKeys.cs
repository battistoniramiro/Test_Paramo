﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Core.Constants
{
    public class ErrorKeys
    {
        public const string UserNotFound = "ErrUserNotFound";
        public const string UserWasNotCreated = "ErrUserWasNotCreated";
        public const string UserAlReadyExists = "ErrUserAlReadyExists";
        public const string UserWasNotModified = "ErrUserWasNotModified";
        public const string UserWasNotDeleted = "ErrUserWasNotModified";
        public const string UserEmailIsNotValid = "ErrUserEmailIsNotValid";
        public const string UserTypeIsNotValid = "ErrUserTypeIsNotValid";
        public const string UsersNoContent = "ErrUsersNoContent";
        public const string UserNameIsRequired = "ErrUserNameIsRequired";
        public const string UserEmailIsRequired = "ErrUserNameIsRequired";
        public const string UserIdInvalidForModifier = "ErrUserIdInvalidForModifier";
    }
}
