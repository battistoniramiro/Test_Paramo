﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Test.Core.Entities;

namespace Test.Core.Repositories.Contracts
{
    public interface IUserRepository
    {
        Task<int> Add(User dto);
        Task<User> GetById(int id);
        Task<User> GetByEmail(string email);
        Task<List<User>> GetAll();
        Task Update(User dto);
        Task Delete(int id);
    }
}
