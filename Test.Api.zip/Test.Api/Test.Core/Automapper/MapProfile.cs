﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Core.Dtos;
using Test.Core.Entities;

namespace Test.Core.Automapper
{
    public class MapProfile :Profile
    {
        public MapProfile()
        {
            CreateMap<UserDto, User>().ReverseMap();
        }
    }
}
