﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Common.Errors;
using Test.Core.Exceptions;

namespace Test.Common
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate next;
        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception ex)
        {

            ProblemDetails err;
            switch (ex)
            {
                case BusinessException BE:
                    err = new InvalidOperationProblemDetails(context, BE);
                    break;
                default:
                    var errorInfo = new InternalServerErrorProblemDetails(context, ex);
                    err = errorInfo;
                    break;
            }

            err.Extensions.Add("ErrorCode", ex.Message);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)err.Status;

            return context.Response.WriteAsync(Newtonsoft.Json.JsonConvert.SerializeObject(err));
        }

    }
}
