﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Common.Errors
{
    public class InternalServerErrorProblemDetails : TraceableProblemDetails
    {
        public InternalServerErrorProblemDetails(HttpContext context, Exception ex)
            : base(context, "https://tools.ietf.org/html/rfc7231#section-6.6.1", "Internal Server Error",
                 500,
                 $"Oops! An unhandled error ocurred. Please contact your System Administrator and provide the following GUID: '{context.TraceIdentifier}'"
                 )
        {
        }

    }
}
