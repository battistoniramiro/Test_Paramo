﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Common.Errors
{
    public class NotFoundProblemDetails : TraceableProblemDetails
    {
        public NotFoundProblemDetails(HttpContext context, Exception ex)
            : base(context,
                  "https://tools.ietf.org/html/rfc7231#section-6.5.4",
                  "Not Found",
                  404, ex.Message)
        {
        }
    }
}
