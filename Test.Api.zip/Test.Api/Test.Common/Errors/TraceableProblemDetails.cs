﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Common.Errors
{
    public abstract class TraceableProblemDetails : ProblemDetails
    {
        protected TraceableProblemDetails(HttpContext context, string type, string title, int statusCode, string details)
        {
            Type = type;
            Title = title;
            Status = statusCode;
            traceId = context.TraceIdentifier;
            Detail = details;
            ErrorCode = details;

        }
        /// <summary>
        /// This field contains a unique identifier for the requests
        /// </summary>
        public string traceId { get; set; }
        public string ErrorCode { get; set; }
    }
}
