﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Common.Errors
{
    public class InvalidOperationProblemDetails : TraceableProblemDetails
    {

        public InvalidOperationProblemDetails(HttpContext context, Exception ex)
            : base(context,
                  "https://tools.ietf.org/html/rfc7231#section-6.5.1",
                  "Invalid Operation Requested",
                  400, ex.Message)
        {
        }
    }
}
