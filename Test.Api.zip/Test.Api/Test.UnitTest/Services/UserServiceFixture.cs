﻿using AutoMapper;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Api.Controllers;
using Test.Core.Contracts.UnitOfWork;
using Test.Core.Dtos;
using Test.Core.Entities;
using Test.Core.Services.Contracts;
using Test.Core.Services.Implementation;
using Test.Infrastructure.Data.UnitOfWork;
using Test.UnitTest.Data;
using Test.UnitTest.Utils;
using Xunit;

namespace Test.UnitTest.Services
{

    public class UserServiceFixture
    {


        [Fact]
        public async void GetAllUserShouldSucceed()
        {
            //Arrage
            var service = new Mock<IUserService>();
            service.Setup(_ => _.GetAll()).ReturnsAsync(UserMockData.GetAll());
            var sut = new UserController(service.Object);

            //Act
            var result = await sut.GetAll();

            //Assert
            result.GetType().Should().Be(typeof(OkObjectResult));
            (result as OkObjectResult).StatusCode.Should().Be(200);

        }
         
    }
}
