﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Core.Dtos;
using Test.Core.Entities;

namespace Test.UnitTest.Data
{
    public class UserMockData
    {



        public static List<User> GetAll()
        {
            return new List<User>()
            {
                new User()
                {
                    Id = 1,
                    Address = "bla bla 123",
                    Email = "abc@gmail.com",
                    Name = "ramiro",
                    Money = Convert.ToDecimal(0.20),
                    Phone = "+543512163513",
                    UserTypeId = 1
                },
                new User()
                {
                    Id = 1,
                    Address = "bla bla 123",
                    Email = "abc@gmail.com",
                    Name = "ramiro",
                    Money = Convert.ToDecimal(0.20),
                    Phone = "+543512163513",
                    UserTypeId = 1
                },
                new User()
                {
                    Id = 1,
                    Address = "bla bla 123",
                    Email = "abc@gmail.com",
                    Name = "ramiro",
                    Money = Convert.ToDecimal(0.20),
                    Phone = "+543512163513",
                    UserTypeId = 1
                },
            };
        }


    }
}
