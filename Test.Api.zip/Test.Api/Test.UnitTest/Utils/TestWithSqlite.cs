﻿using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.UnitTest.Utils
{
    public class TestWithSqlite : IDisposable
    {
        private const string _coonectionString = "DataSource=:memory:";
        protected MockHelper _mockHelper;
        private readonly SqliteConnection _connection;
        protected TestWithSqlite()
        {

            _connection = new SqliteConnection(_coonectionString);

            IConfiguration _configuration = new ConfigurationBuilder().AddInMemoryCollection().Build();

            
            _connection.Open();

            _mockHelper = new MockHelper(_configuration);
        }


        public void Dispose()
        {
            _connection.Dispose();
        }


    }
}
