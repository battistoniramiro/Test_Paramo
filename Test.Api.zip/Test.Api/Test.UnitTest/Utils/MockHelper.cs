﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Test.Core.Contracts.UnitOfWork;
using Test.Core.Services.Implementation;
using Test.Infrastructure.Data.UnitOfWork;

namespace Test.UnitTest.Utils
{
    public class MockHelper
    {
        private readonly IConfiguration _config;
        
        public MockHelper(IConfiguration config)
        {
            _config = config;
        }

        public IUnitOfWork GetUnitOfWork()
        {
            return new UnitOfWork(_config);
        }

        private MapperConfiguration GetMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new Core.Automapper.MapProfile());
            });

            return config;
        }

        public IMapper GetIMapper()
        {
            return GetMapper().CreateMapper();
        }



        #region UserService
        public UserService GetUserService()
        {
            return new UserService(GetUnitOfWork(), GetMapper().CreateMapper());
        }
        #endregion


    }
}