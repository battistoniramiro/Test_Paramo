﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Test.Core.Dtos;
using Test.Core.Services.Contracts;

namespace Test.Api.Controllers
{
    [Route("Api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private readonly IUserService _service;


        public UserController(IUserService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<ActionResult> Add(UserDto dto)
        {
            var result = await _service.Add(dto);
            return Ok(result);
        }

        [HttpGet]
        public async Task<ActionResult> GetById(int id)
        {
            var user = await _service.GetById(id);
            return Ok(user);
        }

        [HttpGet]
        [Route("GetAll")]
        public async Task<ActionResult> GetAll()
        {
            var user = await _service.GetAll();
            return Ok(user);
        }

        [HttpPut]
        public async Task<ActionResult> Update(UserDto dto)
        {
            await _service.Update(dto);
            return Ok();
        }

        [HttpDelete]
        public async Task Delete(int id)
        {
            await _service.Delete(id);
        }
    }
}
